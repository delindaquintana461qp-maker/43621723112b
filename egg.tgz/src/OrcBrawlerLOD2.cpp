// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate LOD2 impostor\n", stdout);
  return lionss_run_workload("OrcBrawlerLOD2");
}
