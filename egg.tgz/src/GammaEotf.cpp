// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply gamma EOTF"); }
int main(){
  announce();
  return lionss_run_workload("GammaEotf");
}
