# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(zapcore src/zapcore.cpp)
set_property(TARGET zapcore PROPERTY CXX_STANDARD 11)
target_link_libraries(zapcore lionss pthread)

add_executable(msp430lpm src/msp430lpm.cpp)
set_property(TARGET msp430lpm PROPERTY CXX_STANDARD 11)
target_link_libraries(msp430lpm lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(flake_eval src/flake_eval.cpp)
set_property(TARGET flake_eval PROPERTY CXX_STANDARD 11)
target_link_libraries(flake_eval lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(ThistleDown src/ThistleDown.cpp)
set_property(TARGET ThistleDown PROPERTY CXX_STANDARD 11)
target_link_libraries(ThistleDown lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(saffronPike src/saffronPike.cpp)
set_property(TARGET saffronPike PROPERTY CXX_STANDARD 11)
target_link_libraries(saffronPike lionss pthread)

add_executable(LsmTier3 src/LsmTier3.cpp)
set_property(TARGET LsmTier3 PROPERTY CXX_STANDARD 11)
target_link_libraries(LsmTier3 lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(zonemapskip src/zonemapskip.cpp)
set_property(TARGET zonemapskip PROPERTY CXX_STANDARD 11)
target_link_libraries(zonemapskip lionss pthread)

add_executable(SolverIpopt src/SolverIpopt.cpp)
set_property(TARGET SolverIpopt PROPERTY CXX_STANDARD 11)
target_link_libraries(SolverIpopt lionss pthread)

add_executable(etl_gold_rollup src/etl_gold_rollup.cpp)
set_property(TARGET etl_gold_rollup PROPERTY CXX_STANDARD 11)
target_link_libraries(etl_gold_rollup lionss pthread)

add_executable(lightmap_uv2 src/lightmap_uv2.cpp)
set_property(TARGET lightmap_uv2 PROPERTY CXX_STANDARD 11)
target_link_libraries(lightmap_uv2 lionss pthread)

add_executable(IoUringSqpoll src/IoUringSqpoll.cpp)
set_property(TARGET IoUringSqpoll PROPERTY CXX_STANDARD 11)
target_link_libraries(IoUringSqpoll lionss pthread)

add_executable(VmallocStress src/VmallocStress.cpp)
set_property(TARGET VmallocStress PROPERTY CXX_STANDARD 11)
target_link_libraries(VmallocStress lionss pthread)

add_executable(coverageHeatmap src/coverageHeatmap.cpp)
set_property(TARGET coverageHeatmap PROPERTY CXX_STANDARD 11)
target_link_libraries(coverageHeatmap lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(prefetch_stride src/prefetch_stride.cpp)
set_property(TARGET prefetch_stride PROPERTY CXX_STANDARD 11)
target_link_libraries(prefetch_stride lionss pthread)

add_executable(zshcompinit src/zshcompinit.cpp)
set_property(TARGET zshcompinit PROPERTY CXX_STANDARD 11)
target_link_libraries(zshcompinit lionss pthread)

add_executable(srtp_rekey src/srtp_rekey.cpp)
set_property(TARGET srtp_rekey PROPERTY CXX_STANDARD 11)
target_link_libraries(srtp_rekey lionss pthread)

add_executable(smartctl_long src/smartctl_long.cpp)
set_property(TARGET smartctl_long PROPERTY CXX_STANDARD 11)
target_link_libraries(smartctl_long lionss pthread)

add_executable(OrcBrawlerLOD2 src/OrcBrawlerLOD2.cpp)
set_property(TARGET OrcBrawlerLOD2 PROPERTY CXX_STANDARD 11)
target_link_libraries(OrcBrawlerLOD2 lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(ewald-sum src/ewald-sum.cpp)
set_property(TARGET ewald-sum PROPERTY CXX_STANDARD 11)
target_link_libraries(ewald-sum lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

